DashGum Template (free version)
===============

[DashGum – Free Dashboard] (http://www.blacktie.co/2014/07/dashgum-free-dashboard/)

Author: [Black Tie] (http://www.blacktie.co/)

##Theme Information

DashGum is a simple & elegant admin panel. It comes with 15 pages to start your panel as soon as possible.

With DashGum you have charts, tables, a lot of panels, calendars, notifications, to do lists and more. Grab our free theme and enjoy it.

If you need more, see our [Premium Version] (http://gridgum.com/themes/dashgum-bootstrap-dashboard/) with tons of more features. With 33 HTMLs and more than 40 plugins, the premium version comes with 4 different chart plugins, Email pages, chat pages, maps, advanced forms and tables, file uploaders, inline editor, pricing tables, complete profile page and more.

Framework Used: Bootstrap 3.2

![Screenshot](http://www.blacktie.co/blog/wp-content/uploads/2014/07/dashgum700.png)
